# data/feature_prior.py
import os
import torch
import torch.nn.functional as F
import numpy as np

def _project_if_needed(t: torch.Tensor, emb_size: int, device):
    """If t's dim != emb_size, project with a frozen linear map to emb_size."""
    t = t.to(device).float()
    d0 = t.size(-1)
    if d0 == emb_size:
        return F.normalize(t, dim=-1).detach()
    gen = torch.Generator(device=device); gen.manual_seed(2025)
    W = torch.randn(d0, emb_size, generator=gen, device=device) / (d0 ** 0.5)
    t_proj = t @ W
    return F.normalize(t_proj, dim=-1).detach()

def _pick_item_tensor(obj, path):
    """Accepts dict (item_embeddings/item_emb/embeddings) or Tensor/ndarray."""
    if isinstance(obj, dict):
        for k in ['item_embeddings', 'item_emb', 'embeddings']:
            if k in obj:
                v = obj[k]
                if isinstance(v, np.ndarray): v = torch.from_numpy(v)
                return v
        raise KeyError(f"No known item tensor key in {path}. Dict keys: {list(obj.keys())}")
    if isinstance(obj, torch.Tensor):
        return obj
    if isinstance(obj, np.ndarray):
        return torch.from_numpy(obj)
    raise TypeError(f"Unsupported item_emb format from {path}: {type(obj)}")

def _pick_user_tensor(obj, path):
    """Accepts dict (user_embeddings/user_emb/embeddings) or Tensor/ndarray."""
    if isinstance(obj, dict):
        for k in ['user_embeddings', 'user_emb', 'embeddings']:
            if k in obj:
                v = obj[k]
                if isinstance(v, np.ndarray): v = torch.from_numpy(v)
                return v
        raise KeyError(f"No known user tensor key in {path}. Dict keys: {list(obj.keys())}")
    if isinstance(obj, torch.Tensor):
        return obj
    if isinstance(obj, np.ndarray):
        return torch.from_numpy(obj)
    raise TypeError(f"Unsupported user_emb format from {path}: {type(obj)}")

def _internal_train_item_indices(data):
    csr = data.interaction_mat.tocsr()
    return np.unique(csr.indices).astype(np.int64)

def _internal_train_user_indices(data):
    csr = data.interaction_mat.tocsr()
    return np.arange(csr.shape[0], dtype=np.int64)


def load_user_item_priors(conf, data, emb_size: int, device):
    """
    Load precomputed priors from ./dataset/<dataset>/{user_emb.pt,item_emb.pt}.
    If priors are larger than SELFRec's internal space, subset/reorder to internal ids.
    Returns (user_prior [U,emb], item_prior [I,emb]) normalized & detached.
    """
    ds = str(conf['dataset']).strip()
    item_path = f'./dataset/{ds}/item_emb.pt'
    user_path = f'./dataset/{ds}/user_emb.pt'

    if not os.path.exists(item_path) or not os.path.exists(user_path):
        raise FileNotFoundError(
            f"Cannot find precomputed priors for dataset '{ds}'.\n"
            f"Expected:\n  {item_path}\n  {user_path}"
        )

    item_obj = torch.load(item_path, map_location=device)
    user_obj = torch.load(user_path, map_location=device)

    item_raw = _pick_item_tensor(item_obj, item_path)  # [I_raw, d0] or [I_int, d0]
    user_raw = _pick_user_tensor(user_obj, user_path)  # [U_raw, d0] or [U_int, d0]

    # Ensure tensors
    if not isinstance(item_raw, torch.Tensor): item_raw = torch.as_tensor(item_raw)
    if not isinstance(user_raw, torch.Tensor): user_raw = torch.as_tensor(user_raw)

    I_int, U_int = int(data.item_num), int(data.user_num)
    I_raw, U_raw = int(item_raw.shape[0]), int(user_raw.shape[0])

    # ---- Align ITEMS ----
    if I_raw == I_int:
        pass  # already aligned
    elif I_raw > I_int:
        internal_items = _internal_train_item_indices(data)  # ids used by SELFRec
        # sanity
        if internal_items.max(initial=0) >= I_raw:
            raise ValueError(
                f"Internal item id {internal_items.max()} exceeds rows in item_emb.pt ({I_raw}). "
                f"Your item_emb.pt likely uses a different id space/order. "
                f"Regenerate to match SELFRec internal ids or provide a mapping."
            )
        if internal_items.size != I_int:
            # If rare mismatch, fall back to first I_int rows to avoid crash,
            # but warn via exception message above in proper setups.
            internal_items = np.arange(I_int, dtype=np.int64)
        item_raw = item_raw[torch.as_tensor(internal_items, device=device, dtype=torch.long)]
    else:
        raise ValueError(f"Item prior rows ({I_raw}) < SELFRec item_num ({I_int}).")

    # ---- Align USERS ----
    if U_raw == U_int:
        pass
    elif U_raw > U_int:
        internal_users = _internal_train_user_indices(data)
        if internal_users.max(initial=0) >= U_raw:
            raise ValueError(
                f"Internal user id {internal_users.max()} exceeds rows in user_emb.pt ({U_raw}). "
                f"Your user_emb.pt likely uses a different id space/order."
            )
        if internal_users.size != U_int:
            internal_users = np.arange(U_int, dtype=np.int64)
        user_raw = user_raw[torch.as_tensor(internal_users, device=device, dtype=torch.long)]
    else:
        raise ValueError(f"User prior rows ({U_raw}) < SELFRec user_num ({U_int}).")

    # ---- Project/normalize/detach ----
    item_prior = _project_if_needed(item_raw, emb_size, device)  # [I_int, emb]
    user_prior = _project_if_needed(user_raw, emb_size, device)  # [U_int, emb]
    return user_prior, item_prior
