from SELFRec import SELFRec
from util.conf import ModelConf
import time
import argparse
parser = argparse.ArgumentParser()
parser.add_argument("--model", default='MoHo2')
parser.add_argument("--dataset", default='pw')
parser.add_argument("--motif_lambda", default=1)

parser.add_argument("--seed", default=2025)
parser.add_argument("--cl_lambda", default=0.01)
parser.add_argument("--lr", default=0.01)
parser.add_argument("--reg", default=0.0001)
parser.add_argument("--eps", default=0.5)
parser.add_argument("--epoch", default=20)
parser.add_argument("--tau_homo", default=0.2)
parser.add_argument("--tau_mixed", default=0.15)
parser.add_argument("--tau_hetero", default=0.1)
parser.add_argument("--viewB_keep_prob_homo", default=0.9)
parser.add_argument("--viewB_keep_prob_mixed", default=0.7)
parser.add_argument("--viewB_keep_prob_hetero", default=0.5)
parser.add_argument("--use_fp", action='store_true')
parser.add_argument("--tau", default=0.05)



args = parser.parse_args()

if __name__ == '__main__':
    models = {
        'Graph-Based Baseline Models': ['LightGCN', 'DirectAU', 'MF', 'MGCN'],
        'Self-Supervised Graph-Based Models': ['SGL', 'SimGCL', 'SEPT', 'MHCN', 'BUIR', 'SelfCF', 'SSL4Rec', 'XSimGCL', 'NCL', 'MixGCF', 'MGCL', 'MGCL2', 'MoHo', 'MoHo2'],
        'Sequential Baseline Models': ['SASRec'],
        'Self-Supervised Sequential Models': ['CL4SRec', 'BERT4Rec']
    }

    model = args.model

    s = time.time()
    all_models = sum(models.values(), [])
    if model in all_models:
        conf = ModelConf(f'./conf/{model}.yaml')
        conf['dataset'] = args.dataset
        conf['learning.rate'] = args.lr
        conf['reg.lambda'] = args.reg
        conf['max.epoch'] = args.epoch
        conf['eps'] = args.eps
        conf['cl_lambda'] = args.cl_lambda
        conf['motif_lambda'] = args.motif_lambda
        conf['tau_homo'] = args.tau_homo
        conf['tau_mixed'] = args.tau_mixed
        conf['tau_hetero'] = args.tau_hetero
        conf['viewB_keep_prob_homo'] = args.viewB_keep_prob_homo
        conf['viewB_keep_prob_mixed'] = args.viewB_keep_prob_mixed
        conf['viewB_keep_prob_hetero'] = args.viewB_keep_prob_hetero
        conf['use_fp'] = args.use_fp
        conf['seed'] = args.seed
        conf['tau'] = args.tau
        rec = SELFRec(conf)
        rec.execute()
        e = time.time()
        print(f"Running time: {e - s:.2f} s")
    else:
        print('Wrong model name!')
        exit(-1)
