import numpy as np

def build_user_hist(ui_pairs: np.ndarray, num_users: int = None):
    order = np.argsort(ui_pairs[:,0], kind='mergesort')
    u_sorted = ui_pairs[order,0]
    i_sorted = ui_pairs[order,1]
    if num_users is None:
        U = int(u_sorted.max()) + 1 if u_sorted.size > 0 else 0
    else:
        U = max(int(num_users), int(u_sorted.max()) + 1 if u_sorted.size > 0 else int(num_users))
    counts = np.bincount(u_sorted, minlength=U)
    indptr = np.zeros(U+1, dtype=np.int64)
    indptr[1:] = np.cumsum(counts)
    return indptr, i_sorted.astype(np.int32, copy=False)


def sample_triads_uniform(indptr, indices, K=30, seed=36):
    rng = np.random.default_rng(seed)
    U = len(indptr) - 1
    triads = []
    for u in range(U):
        s, e = indptr[u], indptr[u+1]
        items = indices[s:e]
        m = len(items)
        if m < 2: 
            continue
        max_pairs = m*(m-1)//2
        target = min(K, max_pairs)
        if max_pairs <= K:
            for a in range(m-1):
                for b in range(a+1, m):
                    i1, i2 = int(items[a]), int(items[b])
                    if i1 > i2: i1, i2 = i2, i1
                    triads.append((u, i1, i2))
        else:
            seen = set()
            trials = 0
            while len(seen) < target and trials < 10*target:
                a, b = rng.choice(m, 2, replace=False)
                i1, i2 = int(items[a]), int(items[b])
                if i1 > i2: i1, i2 = i2, i1
                seen.add((i1, i2))
                trials += 1
            triads.extend((u, i1, i2) for (i1,i2) in seen)
    return np.asarray(triads, dtype=np.int32)

class TriadBatcher:
    def __init__(self, triads: np.ndarray, seed=2025):
        self.triads = triads
        self.rng = np.random.default_rng(seed)
    def next_batch(self, batch_size: int):
        idx = self.rng.integers(0, len(self.triads), size=batch_size)
        b = self.triads[idx]
        return b[:,0], b[:,1], b[:,2]