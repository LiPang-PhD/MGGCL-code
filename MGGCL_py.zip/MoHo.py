import torch
import torch.nn as nn
import torch.nn.functional as F

from base.graph_recommender import GraphRecommender
from util.sampler import next_batch_pairwise
from base.torch_interface import TorchGraphInterface
from util.loss_torch import bpr_loss, l2_reg_loss

# NEW: triad utilities
from data.triad_sampler import build_user_hist, sample_triads_uniform, TriadBatcher
from data.feature_prior import load_user_item_priors


class MoHo(GraphRecommender):
    def __init__(self, conf, training_set, test_set):
        super(MoHo, self).__init__(conf, training_set, test_set)
        args = self.config['MoHo']
        self.cl_rate   = float(args['lambda'])      # weight on CL vs CF
        self.eps       = float(args['eps'])         # SimGCL noise
        self.n_layers  = int(args['n_layer'])
        self.emb_size  = int(self.config['embedding.size'])
        self.batch_size= int(self.config['batch.size'])
        self.maxEpoch  = int(self.config['max.epoch'])
        self.reg       = float(self.config['reg.lambda'])
        self.lRate     = float(self.config['learning.rate'])

        # MoHo extras from YAML (defaults if missing)
        self.K_triads  = int(args.get('triads_per_user', 30))
        self.gamma     = float(args.get('gamma', 1.0))
        self.q_initial = float(args.get('q_initial', 0.60))
        self.q_final   = float(args.get('q_final',   0.70))
        self.q_warmup  = int(args.get('q_warmup_epochs', 8))

        # type-adaptive temperatures (initialized; learnable)
        self.tau_homo   = nn.Parameter(torch.tensor(float(args.get('tau_homo', 0.20))))
        self.tau_mixed  = nn.Parameter(torch.tensor(float(args.get('tau_mixed', 0.15))))
        self.tau_hetero = nn.Parameter(torch.tensor(float(args.get('tau_hetero',0.10))))

        # keep probs for View B row-scaling (approx type-aware edge-drop)
        self.keep_h = float(args.get('viewB_keep_prob', {}).get('homo',   0.9))
        self.keep_m = float(args.get('viewB_keep_prob', {}).get('mixed',  0.7))
        self.keep_he= float(args.get('viewB_keep_prob', {}).get('hetero', 0.5))

        # encoder
        self.model = MoHo_Encoder(self.data, self.emb_size, self.eps, self.n_layers)
        
        # Cache the CSR once; Interaction gives interaction_mat (U x I)
        self.inter_csr = self.data.interaction_mat.tocsr()
        self.user_items_list = self._build_user_items_list_from_csr(self.inter_csr)

        # ---- triads (once) ----
        ui_pairs = self.get_ui_pairs_numpy()
        print("CSR U,I:", self.data.user_num, self.data.item_num,
        "| ui_pairs:", ui_pairs.shape, 
        "| max u:", ui_pairs[:,0].max(), "max i:", ui_pairs[:,1].max())
        indptr, user_items = build_user_hist(ui_pairs)

        triads = sample_triads_uniform(indptr, user_items, K=self.K_triads, seed=2025)
        self.triad_batcher = TriadBatcher(triads, seed=2025)
        
        # ---- feature-as-prior config ----
        fp = args.get('feature_prior', {})
        self.fp_use    = bool(fp.get('use', False))
        self.fp_lstart = float(fp.get('lambda_start', 1.0))
        self.fp_lend   = float(fp.get('lambda_end',   0.0))
        self.fp_lepoch = int(fp.get('lambda_epochs',  5))

        self.user_prior = None
        self.item_prior = None
        if self.fp_use:
            device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
            # load user/item priors directly from user_emb.pt / item_emb.pt
            self.user_prior, self.item_prior = load_user_item_priors(
                self.config, self.data, self.emb_size, device
            )

    def _build_user_items_list_from_csr(self, csr):
        U = csr.shape[0]
        user_items = [[] for _ in range(U)]
        indptr, indices = csr.indptr, csr.indices
        for u in range(U):
            s, e = indptr[u], indptr[u+1]
            user_items[u].extend(indices[s:e].tolist())
        return user_items

    def get_ui_pairs_numpy(self):
        import numpy as np
        csr = self.inter_csr
        u = np.repeat(np.arange(csr.shape[0], dtype=np.int32), np.diff(csr.indptr))
        i = csr.indices.astype(np.int32, copy=False)
        return np.stack([u, i], axis=1)  # [N,2]


    @torch.no_grad()
    def _estimate_tau_quantile(self, E_users, E_items, q=0.65, sample_u=20000, sample_i=20000):
        # global quantile over random subset (fast)
        U = min(sample_u, E_users.size(0))
        I = min(sample_i, E_items.size(0))
        iu = torch.randint(0, E_users.size(0), (U,), device=E_users.device)
        ii = torch.randint(0, E_items.size(0), (I,), device=E_items.device)
        eu = F.normalize(E_users[iu], dim=-1)
        ei = F.normalize(E_items[ii], dim=-1)
        sims = eu @ ei.T
        return torch.quantile(sims.reshape(-1), q)

    def train(self):
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.model = self.model.to(device)
        optimizer = torch.optim.Adam(self.model.parameters(), lr=self.lRate, weight_decay=0.0)

        for epoch in range(self.maxEpoch):
            self.model.train()

            # ---- snapshot for stats (NO GRAD) ----
            with torch.no_grad():
                E_u_snap, E_i_snap = self.model.forward(view='base')
                q = self.q_initial + (min(epoch, self.q_warmup) / max(1, self.q_warmup)) * (self.q_final - self.q_initial)
                tau_q = self._estimate_tau_quantile(E_u_snap, E_i_snap, q=q)
                uh_homo, uh_mixed, uh_hetero = self._estimate_user_motif_fractions(
                    E_u_snap, E_i_snap, tau_q, sample_users=20000
                )
                p_keep_u = (uh_homo * self.keep_h) + (uh_mixed * self.keep_m) + (uh_hetero * self.keep_he)
                # cache View-B for the epoch (stop-grad)
                E_u_B, E_i_B = self.model.forward(view='row_scaled', row_keep=p_keep_u)

            # ---- batch loop ----
            for n, batch in enumerate(next_batch_pairwise(self.data, self.batch_size)):
                user_idx, pos_idx, neg_idx = batch
                user_idx = torch.as_tensor(user_idx, device=device, dtype=torch.long)
                pos_idx  = torch.as_tensor(pos_idx,  device=device, dtype=torch.long)
                neg_idx  = torch.as_tensor(neg_idx,  device=device, dtype=torch.long)

                # Base embeddings WITH grad (fresh graph per batch)
                E_u_base, E_i_base = self.model.forward(view='base')
                # View-A: SimGCL noise from current base (keeps grad)
                E_u_A, E_i_A = self.model.forward_from_embeddings(E_u_base, E_i_base, perturbed=True)

                # CF loss
                u_emb = E_u_base[user_idx]
                p_emb = E_i_base[pos_idx]
                n_emb = E_i_base[neg_idx]
                rec_loss = bpr_loss(u_emb, p_emb, n_emb)
                reg_loss = l2_reg_loss(self.reg, u_emb, p_emb, n_emb)  # include neg

                # Triad batch
                u_t, i1_t, i2_t = self.triad_batcher.next_batch(self.batch_size)
                u_t  = torch.as_tensor(u_t,  device=device, dtype=torch.long)
                i1_t = torch.as_tensor(i1_t, device=device, dtype=torch.long)
                i2_t = torch.as_tensor(i2_t, device=device, dtype=torch.long)

                # Views for contrastive
                zA = self._triad_pool(E_u_A[u_t], E_i_A[i1_t], E_i_A[i2_t])          # with grad
                zB = self._triad_pool(E_u_B[u_t], E_i_B[i1_t], E_i_B[i2_t])          # stop-grad cached

                # Blended label similarities (detach)
                lam = 0.0
                if self.fp_use:
                    r = 0.0 if self.fp_lepoch <= 0 else min(epoch, self.fp_lepoch) / float(self.fp_lepoch)
                    lam = max(0.0, min(1.0, self.fp_lstart + (self.fp_lend - self.fp_lstart) * r))

                s1 = F.cosine_similarity(E_u_base[u_t], E_i_base[i1_t])
                s2 = F.cosine_similarity(E_u_base[u_t], E_i_base[i2_t])
                if self.fp_use and lam > 0.0:
                    eu_p  = self.user_prior[u_t]
                    ei1_p = self.item_prior[i1_t]
                    ei2_p = self.item_prior[i2_t]
                    s1_p = F.cosine_similarity(eu_p, ei1_p)
                    s2_p = F.cosine_similarity(eu_p, ei2_p)
                    s1 = lam * s1_p + (1.0 - lam) * s1
                    s2 = lam * s2_p + (1.0 - lam) * s2
                s1 = s1.detach(); s2 = s2.detach()

                w_h, w_m, w_he = self._soft_labels(s1, s2, tau_q)
                tau_vec = (w_h * self.tau_homo + w_m * self.tau_mixed + w_he * self.tau_hetero).clamp_min(1e-4)
                cl_loss = self._supcon_pairwise(zA, zB, tau_vec, w_h, w_m, w_he)

                loss = rec_loss + reg_loss + self.cl_rate * cl_loss
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

                if n % 100 == 0 and n > 0:
                    print(f'[Ep {epoch+1} | batch {n}] rec={rec_loss.item():.4f} reg={reg_loss.item():.4f} cl={cl_loss.item():.4f}')

            # refresh best embeddings for evaluation
            with torch.no_grad():
                self.user_emb, self.item_emb = self.model.forward(view='base')
            self.fast_evaluation(epoch)

        self.user_emb, self.item_emb = self.best_user_emb, self.best_item_emb


    def save(self):
        with torch.no_grad():
            self.best_user_emb, self.best_item_emb = self.model.forward(view='base')

    def predict(self, u):
        u = self.data.get_user_id(u)
        score = torch.matmul(self.user_emb[u], self.item_emb.transpose(0, 1))
        return score.cpu().numpy()

    # ---------- MoHo helpers ----------
    def _triad_pool(self, eu, ei1, ei2):
        # simplest: role-aware concat (you can swap to mean if you want [d])
        return torch.cat([eu, ei1, ei2], dim=-1)

    def _soft_labels(self, s1, s2, tau):
        sig = torch.sigmoid
        w_h  = sig(s1 - tau) * sig(s2 - tau)
        w_he = sig(tau - s1) * sig(tau - s2)
        w_m  = (1.0 - w_h - w_he).clamp_min(0.0)
        Z = (w_h + w_m + w_he + 1e-9)
        return w_h/Z, w_m/Z, w_he/Z

    @torch.no_grad()
    def _estimate_user_motif_fractions(self, E_u, E_i, tau, sample_users=20000):
        device = E_u.device
        U = E_u.size(0)
        mask = torch.zeros(U, dtype=torch.bool, device=device)
        sel = torch.randint(0, U, (min(U, sample_users),), device=device)
        mask[sel] = True

        homo  = torch.zeros(U, device=device)
        mixed = torch.zeros(U, device=device)
        heter = torch.zeros(U, device=device)

        # --- safety: ensure dense 2D ---
        if E_i.dim() != 2 or E_u.dim() != 2:
            raise RuntimeError(f"Expected dense 2D embeddings, got E_u={E_u.shape}, E_i={E_i.shape}")

        for u in sel.tolist():
            items = self.user_items_list[u]
            m = len(items)
            if m < 2:
                continue

            # sample up to 20 items
            K = min(20, m)
            # pick K distinct indices into 'items' (CPU list ops are fine here)
            # use torch on CPU then convert to Python ints for speed
            idx_local = torch.randperm(m, device=device)[:K].tolist()
            samp = [items[j] for j in idx_local]

            # sample up to 20 pairs from these K
            if K < 2:
                continue
            a = torch.randint(0, K, (20,), device=device)
            b = torch.randint(0, K, (20,), device=device)
            idx1_list, idx2_list = [], []
            for ai, bi in zip(a.tolist(), b.tolist()):
                if ai == bi:
                    continue
                idx1_list.append(samp[ai])
                idx2_list.append(samp[bi])

            if not idx1_list:
                continue

            # --- use index_select with 1D long tensors (avoids fancy indexing pitfalls) ---
            idx1 = torch.tensor(idx1_list, device=device, dtype=torch.long)
            idx2 = torch.tensor(idx2_list, device=device, dtype=torch.long)

            eu   = E_u[u].unsqueeze(0)                               # [1,d]
            e_i1 = torch.index_select(E_i, 0, idx1)                  # [P,d]
            e_i2 = torch.index_select(E_i, 0, idx2)                  # [P,d]

            # broadcast eu to [P,d] for cosine
            s1 = F.cosine_similarity(eu.expand_as(e_i1), e_i1)
            s2 = F.cosine_similarity(eu.expand_as(e_i2), e_i2)

            w_h, w_m, w_he = self._soft_labels(s1, s2, tau)
            homo[u]  = w_h.mean()
            mixed[u] = w_m.mean()
            heter[u] = w_he.mean()

        g_h = homo[mask].mean() if mask.any() else torch.tensor(1/3, device=device)
        g_m = mixed[mask].mean() if mask.any() else torch.tensor(1/3, device=device)
        g_he= heter[mask].mean() if mask.any() else torch.tensor(1/3, device=device)
        # fill unsampled users
        homo[~mask]  = g_h if not torch.isnan(g_h) else 1/3
        mixed[~mask] = g_m if not torch.isnan(g_m) else 1/3
        heter[~mask] = g_he if not torch.isnan(g_he) else 1/3

        Z = (homo + mixed + heter + 1e-9)
        return homo/Z, mixed/Z, heter/Z

    def _supcon_pairwise(self, zA, zB, tau_vec, w_h, w_m, w_he):
        """Minimal SupCon over two views with soft motif weights and per-sample temperature.
           Treat (zA_i, zB_i) as paired positives; all others are negatives."""
        # normalize
        zA = F.normalize(zA, dim=-1); zB = F.normalize(zB, dim=-1)
        sim = zA @ zB.T                                  # [B,B]
        # build logits per-anchor with its temperature
        # logits_ij = sim_ij / tau_i
        tau = tau_vec.unsqueeze(1)                       # [B,1]
        logits = sim / tau

        # positives are the diagonal pairs (i,i)
        B = zA.size(0)
        labels = torch.arange(B, device=zA.device, dtype=torch.long)

        # InfoNCE with diagonal positives (SupCon minimal form)
        # subtract max for numeric stability
        logits = logits - logits.max(dim=1, keepdim=True)[0]
        exp_logits = torch.exp(logits)
        pos = torch.exp(torch.diag(logits))              # [B]
        denom = exp_logits.sum(dim=1) + 1e-9
        loss = - torch.log(pos / denom + 1e-12).mean()

        # (Optional) weight by motif confidence; here we already used tau_vec from weights.
        return loss

class MoHo_Encoder(nn.Module):
    def __init__(self, data, emb_size, eps, n_layers):
        super(MoHo_Encoder, self).__init__()
        self.data = data
        self.eps = eps
        self.emb_size = emb_size
        self.n_layers = n_layers
        self.norm_adj = data.norm_adj
        self.sparse_norm_adj = TorchGraphInterface.convert_sparse_mat_to_tensor(self.norm_adj).cuda()

        initializer = nn.init.xavier_uniform_
        self.user_emb = nn.Parameter(initializer(torch.empty(self.data.user_num, self.emb_size)))
        self.item_emb = nn.Parameter(initializer(torch.empty(self.data.item_num, self.emb_size)))

    @torch.no_grad()
    def _row_scale_adj(self, row_keep):
        """Fast approximation of type-aware edge drop: multiply each USER row by keep prob.
           row_keep: [num_users] in [0,1]; stacked with ones for item rows."""
        device = self.sparse_norm_adj.device
        U = self.data.user_num
        I = self.data.item_num
        row_keep = row_keep.clamp(0.0, 1.0)
        scale = torch.cat([row_keep, torch.ones(I, device=device)], dim=0)  # [U+I]
        # implement D * A where D is diagonal(scale)
        # for SparseTensor, scale rows by multiplying values at row indices
        A = self.sparse_norm_adj.coalesce()
        idx = A.indices()   # [2, nnz]
        vals = A.values()   # [nnz]
        row = idx[0]        # row indices
        vals = vals * scale[row]
        return torch.sparse_coo_tensor(idx, vals, A.size(), device=device)

    def _propagate(self, A, user_emb, item_emb, perturbed=False):
        E = torch.cat([user_emb, item_emb], dim=0)   # [U+I, d]
        all_layers = []
        for _ in range(self.n_layers):
            E = torch.sparse.mm(A, E)
            if perturbed:
                noise = torch.rand_like(E)
                E = E + torch.sign(E) * F.normalize(noise, dim=-1) * self.eps
            all_layers.append(E)
        H = torch.stack(all_layers, dim=1).mean(dim=1)
        U = self.data.user_num
        return H[:U], H[U:]

    def forward(self, view='base', row_keep=None):
        """view: 'base' uses A; 'row_scaled' scales user rows by keep probs"""
        if view == 'base':
            return self._propagate(self.sparse_norm_adj, self.user_emb, self.item_emb, perturbed=False)
        elif view == 'row_scaled':
            assert row_keep is not None, "row_keep required for row_scaled"
            A_scaled = self._row_scale_adj(row_keep)
            return self._propagate(A_scaled, self.user_emb, self.item_emb, perturbed=False)
        else:
            raise ValueError(f'unknown view {view}')

    def forward_from_embeddings(self, E_u_base, E_i_base, perturbed=True):
        """Make a noisy view from provided base embeddings (SimGCL-style) without another spmm."""
        E_u = E_u_base; E_i = E_i_base
        if perturbed:
            E_u = E_u + torch.sign(E_u) * F.normalize(torch.rand_like(E_u), dim=-1) * self.eps
            E_i = E_i + torch.sign(E_i) * F.normalize(torch.rand_like(E_i), dim=-1) * self.eps
        return E_u, E_i
