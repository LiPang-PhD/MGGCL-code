import numpy as np
from scipy import sparse as sp
from itertools import combinations, islice
import time
from collections import defaultdict
from tqdm import tqdm
from re import split
import argparse
from multiprocessing import Pool


parser = argparse.ArgumentParser()
parser.add_argument("--motif_type", type=int, default=2, choices={1,2,3,4,5,6,7})
parser.add_argument("--dataset", default='programmableweb')
args = parser.parse_args()

print(f'Generating madj{args.motif_type}...')

training_data = []
with open(f'{args.dataset}/train.txt') as f:
    for line in f:
        items = split(' ', line.strip())
        user_id = items[0]
        item_id = items[1]
        weight = items[2]
        training_data.append([int(user_id), int(item_id),float(weight)])

all_users = {}
all_items = {}
training_set_u = defaultdict(dict)
training_set_i = defaultdict(dict)

for entry in training_data:
    user, item, rating = entry
    if user not in all_users:
        all_users[user] = len(all_users)
    if item not in all_items:
        all_items[item] = len(all_items)
    training_set_u[user][item] = rating
    training_set_i[item][user] = rating

user_num = len(training_set_u)
item_num = len(training_set_i)

num_v = user_num + item_num
row_idx = [all_users[pair[0]] for pair in training_data]
col_idx = [all_items[pair[1]] for pair in training_data]
user_np = np.array(row_idx)
item_np = np.array(col_idx)
edges = np.vstack((user_np, item_np + user_num)).T
edges = np.unique(edges,axis=0)

start_time = time.time()

def chunk(it, size):
    it = iter(it)
    return iter(lambda: tuple(islice(it, size)), ())

def worker6(comb):
    madj_worker = sp.lil_matrix((num_v,num_v),dtype=np.float32)
    for item_id1, item_id2 in comb:
        mutual_users = np.intersect1d(user_groups[item_id1],user_groups[item_id2])
        num_mutual = len(mutual_users)
        
        if num_mutual > 1:
            madj_worker[item_id1, item_id2] += num_mutual*(num_mutual-1)/2
            incre_ui = num_mutual-1
            incre_uu = 1

            for user_id in mutual_users:
                madj_worker[user_id,item_id1] += incre_ui
                madj_worker[user_id,item_id2] += incre_ui

            for user_id1,user_id2 in combinations(mutual_users,2):
                madj_worker[user_id1,user_id2] += incre_uu
                
    return madj_worker.tocsr()

def worker7(comb):
    madj_worker = sp.lil_matrix((num_v,num_v),dtype=np.float32)
    # i = 0
    for item_id1, item_id2 in comb:
        mutual_users = np.intersect1d(user_groups[item_id1],user_groups[item_id2])
        diff_users = np.setdiff1d(np.union1d(user_groups[item_id1],user_groups[item_id2]),mutual_users)

        num_mutual = len(mutual_users)
        num_diff = len(diff_users)
        
        if num_mutual > 0 and num_diff > 0:
            madj_worker[item_id1, item_id2] += num_diff * num_mutual

            for mutual_user_id in mutual_users:
                madj_worker[mutual_user_id,item_id1] += num_diff
                madj_worker[mutual_user_id,item_id2] += num_diff
                for diff_user_id in diff_users:
                    madj_worker[diff_user_id,mutual_user_id] += 1

            for diff_user_id in diff_users:
                madj_worker[diff_user_id,item_id1] += num_mutual
                madj_worker[diff_user_id,item_id2] += num_mutual

    return madj_worker.tocsr()


match args.motif_type:
    case 1:
        ratings = np.ones(len(edges), dtype=np.float32)
        tmp_adj = sp.csr_matrix((ratings, (edges.T[0], edges.T[1])), shape=(num_v, num_v),dtype=np.float32)
        madj = tmp_adj + tmp_adj.T

    case 2:
        edges_sorted=edges[edges[:,0].argsort()]
        # divide item into groups by user
        user_ids,edge_indices = np.unique(edges_sorted[:,0], return_index=True)
        item_groups = np.split(edges_sorted[:,1],edge_indices[1:])
        # build a dict in which user_id : an array of item_ids
        item_groups = dict(zip(user_ids, item_groups))
        madj = sp.lil_matrix((num_v,num_v))

        for user_id,item_group in tqdm(item_groups.items()):
            num_items = len(item_group)

            if num_items >= 2:
                incre_ui = num_items-1
                incre_ii = 1

                for item_id in item_group:
                    madj[user_id,item_id] += incre_ui

                for item_id1,item_id2 in combinations(item_group,2):
                    madj[item_id1,item_id2] += incre_ii

        madj = madj.tocsr() + madj.T.tocsr()

    case 3:
        edges_sorted=edges[edges[:,1].argsort()]
        # divid user into groups by item
        item_ids,edge_indices = np.unique(edges_sorted[:,1], return_index=True)
        user_groups = np.split(edges_sorted[:,0],edge_indices[1:])
        # build a dict in which item_id : an array of user_ids
        user_groups = dict(zip(item_ids, user_groups))
        madj = sp.lil_matrix((num_v,num_v),dtype=np.float32)
                        
        for item_id,user_group in tqdm(user_groups.items()):
            num_users = len(user_group)
            
            if num_users >= 3:
                incre_ma = num_users-1
                incre_mm = 1
                
                for user_id in user_group:
                    madj[user_id,item_id] += incre_ma
                    
                for user_id1,user_id2 in combinations(user_group,2):
                    madj[user_id1,user_id2] += incre_mm
                        
        madj = madj.tocsr() + madj.T.tocsr()

    case 4:
        edges_sorted=edges[edges[:,0].argsort()]
        # divid item into groups by user
        user_ids,edge_indices = np.unique(edges_sorted[:,0], return_index=True)
        item_groups = np.split(edges_sorted[:,1],edge_indices[1:])
        # build a dict in which user_id : an array of item_ids
        item_groups = dict(zip(user_ids, item_groups))
        
        madj = sp.lil_matrix((num_v,num_v),dtype=np.float32)
        for user_id,item_group in tqdm(item_groups.items()):
            num_items = len(item_group)

            if num_items >= 3:
                incre_ma = (num_items-1)*(num_items-2)/2
                incre_aa = num_items-2

                for item_id in item_group:
                    madj[user_id,item_id] += incre_ma

                for item_id1,item_id2 in combinations(item_group,2):
                    madj[item_id1,item_id2] += incre_aa
                    
        madj = madj.tocsr() + madj.T.tocsr()

    case 5:
        edges_sorted=edges[edges[:,1].argsort()]
        # divid user into groups by item
        item_ids,edge_indices = np.unique(edges_sorted[:,1], return_index=True)
        user_groups = np.split(edges_sorted[:,0],edge_indices[1:])
        # build a dict in which item_id : an array of user_ids
        user_groups = dict(zip(item_ids, user_groups))
        madj = sp.lil_matrix((num_v,num_v),dtype=np.float32)
                        
        for item_id,user_group in tqdm(user_groups.items()):
            num_users = len(user_group)
            
            if num_users >= 3:
                incre_ma = (num_users-1)*(num_users-2)/2
                incre_mm = num_users-2
                
                for user_id in user_group:
                    madj[user_id,item_id] += incre_ma
                    
                for user_id1,user_id2 in combinations(user_group,2):
                    madj[user_id1,user_id2] += incre_mm
                    
        madj = madj.tocsr() + madj.T.tocsr()

    case 6:
        edges_sorted=edges[edges[:,1].argsort()]
        item_ids,edge_indices = np.unique(edges_sorted[:,1], return_index=True)
        user_groups = np.split(edges_sorted[:,0],edge_indices[1:])
        # build a dict in which item_id : an array of user_ids, the array contains more than one user_ids
        user_groups = {item_ids[i]:group for i,group in enumerate(user_groups) if len(group) > 1}
        madj = sp.csr_matrix((num_v,num_v),dtype=np.float32)
        all_combs = chunk(combinations(user_groups.keys(),2),1000000)
        pool = Pool(12)
        sub_madjs=[]
        for sub_madj in pool.imap_unordered(worker6, all_combs):
            sub_madjs.append(sub_madj)
        pool.close()
        pool.join()
        madj = sum(sub_madjs)

        madj = madj + madj.T

    case 7:
        edges_sorted=edges[edges[:,1].argsort()]
        item_ids,edge_indices = np.unique(edges_sorted[:,1], return_index=True)
        user_groups = np.split(edges_sorted[:,0],edge_indices[1:])
        # build a dict in which item_id : an array of user_ids, the array contains more than one user_ids
        user_groups = {item_ids[i]:group for i,group in enumerate(user_groups) if len(group) > 1}

        madj = sp.csr_matrix((num_v,num_v),dtype=np.float32)
        all_combs = chunk(combinations(user_groups.keys(),2),1000000)
        pool = Pool(12)
        sub_madjs=[]
        for sub_madj in pool.imap_unordered(worker7, all_combs):
            sub_madjs.append(sub_madj)
        pool.close()
        pool.join()
        madj = sum(sub_madjs)

        madj = madj + madj.T


print(f'Generated madj{args.motif_type} in {time.time()-start_time} seconds.')
print(f'Density: {madj.count_nonzero()/madj.shape[0]**2}')
print('Saving madj...')
sp.save_npz(f'{args.dataset}/train_m{args.motif_type}.npz', madj)
